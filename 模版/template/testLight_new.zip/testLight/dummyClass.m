classdef dummyClass < handle
    properties
        app
    end
    
    methods
        function turnON(dummy)
            dummy.app.Switch.Value='On';
        end
        function turnOFF(dummy)
            dummy.app.Switch.Value='Off';
        end
    end
    
    
end