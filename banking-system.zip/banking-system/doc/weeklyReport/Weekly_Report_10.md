# CS132 Project2: Banking System Team 07 Week Report 10

Participants: Jintong Luo, Xinyue Hu, Wenlin Zhu

Meeting Date: 2024.06.21

Project Leader: Jintong Luo

## Summary

Things finished since last meeting

Jintong Luo: Requirement part was finished. Helping Wenlin Zhu to implement validation.

Xinyue Hu: Fix bugs found in validation. Helping Wenlin Zhu to implement validation.

Wenlin Zhu: Write codes for unit test.

## Problems

Nothing.

## Action Items (Plan for the next week)

Jintong Luo: Continue validation.

Xinyue Hu: Continue validation.

Wenlin Zhu: Write the document for validation.
