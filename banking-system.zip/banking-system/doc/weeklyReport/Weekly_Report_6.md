# CS132 Project2: Banking System Team 07 Week Report 6

Participants: Jintong Luo, Xinyue Hu, Wenlin Zhu

Meeting Date: 2024.05.16

Project Leader: Jintong Luo

## Summary

Things finished since last meeting

Jintong Luo: Revise the requirement for problems found in development.

Xinyue Hu: Continuing working on the prototype of the Banking system development.

Wenlin Zhu: Nothing.

We were having midterm examinations and waiting for API these weeks.

## Problems

Nothing.

## Action Items (Plan for the next week)

Jintong Luo: Continue refining system requirement if necessary.

Xinyue Hu: Finish developing the prototype for the Banking system backend and consider the given API.

Wenlin Zhu: Nothing, do the development for her own part. Start to consider test cases based on requirement.
