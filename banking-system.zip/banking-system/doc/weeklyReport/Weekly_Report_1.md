# CS132 Project2: Banking System Team 07 Week Report 1

Participants: Jintong Luo, Xinyue Hu, Wenlin Zhu

Meeting Date: 2024.03.25

Project Leader: Jintong Luo

## Summary

Things finished since last meeting

Jintong Luo: Revise the requirement and draw class diagram and use case diagram.

Xinyue Hu: Check the requirement and give some advice.

Wenlin Zhu: Check the requirement and give some advice.

## Problems

1. The system should ask whether the user needs a bill after successful service.
2. Add commission charge for transfer
3. Add more details for opening account procedure

## Questions prepared for the instructor team

1. What are the differences between APP and ATM? Are there any differences in what they should realize? (IMPORTANT!!!)
2. What does open account mean? Are there any limits?
3. Should the bank tellers be included in the actors?

## Action Items (Plan for the next week)

Jintong Luo: Modify some details of requirement and draw and modify UML.

Xinyue Hu: Nothing.

Wenlin Zhu: Nothing.
