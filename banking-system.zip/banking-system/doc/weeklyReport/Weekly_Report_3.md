# CS132 Project2: Banking System Team 07 Week Report 3

Participants: Jintong Luo, Xinyue Hu, Wenlin Zhu

Meeting Date: 2024.04.11

Project Leader: Jintong Luo

## Summary

Things finished since last meeting

Jintong Luo: Prepare for the consulation and revise the requirement.

Xinyue Hu: Learn QT.

Wenlin Zhu: Learn QT.

## Problems

Nothing.

## Action Items (Plan for the next week)

Jintong Luo: Learn QT.

Xinyue Hu: Start to draw the UML for specification part and decide the architecture of the system. Learn QT as well.

Wenlin Zhu: Learn QT.
