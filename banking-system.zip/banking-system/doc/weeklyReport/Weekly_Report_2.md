# CS132 Project2: Banking System Team 07 Week Report 2

Participants: Jintong Luo, Xinyue Hu, Wenlin Zhu

Meeting Date: 2024.04.01

Project Leader: Jintong Luo

## Summary

Things finished since last meeting

Jintong Luo: Revise the requirement and complete the UML for requirement part.

Xinyue Hu: Check the requirement and give some advice.

Wenlin Zhu: Check the requirement and give some advice.

## Problems

1. What should be included in the system architecture diagram? Are they related to the specification part?

## Action Items (Plan for the next week)

Jintong Luo: Check and modify some details of requirement. Learn QT as well.

Xinyue Hu: Start to draw the UML for specification part and decide the architecture of the system. Learn QT as well.

Wenlin Zhu: Learn QT.
