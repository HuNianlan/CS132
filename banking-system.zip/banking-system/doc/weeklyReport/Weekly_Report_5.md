# CS132 Project2: Banking System Team 07 Week Report 5

Participants: Jintong Luo, Xinyue Hu, Wenlin Zhu

Meeting Date: 2024.04.29

Project Leader: Jintong Luo

## Summary

Things finished since last meeting

Jintong Luo: Revise the requirement for problems found in development.

Xinyue Hu: Continuing working on the prototype of the Banking system development.

Wenlin Zhu: Nothing.

## Problems

Some security-related vulnerabilities were found and need to be fixed in a timely manner.

## Action Items (Plan for the next week)

Jintong Luo: Continue refining system requirement if necessary.

Xinyue Hu: Continue developing the prototype for the Banking system backend and trying to fix the bug.

Wenlin Zhu: Nothing, do the development for her own part.
