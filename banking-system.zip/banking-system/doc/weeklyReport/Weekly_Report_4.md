# CS132 Project2: Banking System Team 07 Week Report 4

Participants: Jintong Luo, Xinyue Hu, Wenlin Zhu

Meeting Date: 2024.04.22

Project Leader: Jintong Luo

## Summary

Things finished since last meeting

Jintong Luo: Polish up Banking system requirement documents.

Xinyue Hu: Began working on the initial design of the Banking system development.

Wenlin Zhu: Nothing.

## Problems

Discussed security measures for the banking system, including encryption for the database.

## Action Items (Plan for the next week)

Jintong Luo: Continue refining requirement if necessary.

Xinyue Hu: Develop a prototype for the Banking system backend.

Wenlin Zhu: Nothing, do the development for her own part.
