# CS132 Project2: Banking System Team 07 Week Report 9

Participants: Jintong Luo, Xinyue Hu, Wenlin Zhu

Meeting Date: 2024.06.11

Project Leader: Jintong Luo

## Summary

Things finished since last meeting

Jintong Luo: Revise the requirement for problems found in development.

Xinyue Hu: Complete the Banking system with API implemented.

Wenlin Zhu: Nothing.

## Problems

Nothing.

## Action Items (Plan for the next week)

Jintong Luo: Continue refining system requirement if necessary.

Xinyue Hu: Nothing, her part has finished well.

Wenlin Zhu: Start validation.
